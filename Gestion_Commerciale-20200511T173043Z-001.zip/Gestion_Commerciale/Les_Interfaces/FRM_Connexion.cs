﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Commerciale.Les_Interfaces
{
    public partial class FRM_Connexion : Form
    {
        public FRM_Connexion()
        {
            InitializeComponent();
        }
    }
}
